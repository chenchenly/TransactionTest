CREATE VIEW schema_tables_with_full_table_scans AS
  SELECT
    `performance_schema`.`table_io_waits_summary_by_index_usage`.`OBJECT_SCHEMA`                       AS `object_schema`,
    `performance_schema`.`table_io_waits_summary_by_index_usage`.`OBJECT_NAME`                         AS `object_name`,
    `performance_schema`.`table_io_waits_summary_by_index_usage`.`COUNT_READ`                          AS `rows_full_scanned`,
    `sys`.`format_time`(`performance_schema`.`table_io_waits_summary_by_index_usage`.`SUM_TIMER_WAIT`) AS `latency`
  FROM `performance_schema`.`table_io_waits_summary_by_index_usage`
  WHERE (isnull(`performance_schema`.`table_io_waits_summary_by_index_usage`.`INDEX_NAME`) AND
         (`performance_schema`.`table_io_waits_summary_by_index_usage`.`COUNT_READ` > 0))
  ORDER BY `performance_schema`.`table_io_waits_summary_by_index_usage`.`COUNT_READ` DESC;
